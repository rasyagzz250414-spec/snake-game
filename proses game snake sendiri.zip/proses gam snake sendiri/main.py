from kivy.app import App
from kivy.uix.widget import Widget
from kivy.properties import ListProperty, NumericProperty
from kivy.clock import Clock
from kivy.core.window import Window
from random import randint

class SnakeGame(Widget):
    snake = ListProperty([(100, 100), (80, 100), (60, 100)])
    food = ListProperty([200, 200])
    direction = ListProperty([20, 0])
    score = NumericProperty(0)

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.cell_size = 20
        Clock.schedule_interval(self.update, 0.1)

    def update(self, dt):
        head_x, head_y = self.snake[0]
        new_head = [head_x + self.direction[0], head_y + self.direction[1]]

        if new_head[0] < 0 or new_head[0] > Window.width or new_head[1] < 0 or new_head[1] > Window.height:
            self.reset_game()
            return

        if new_head in self.snake:
            self.reset_game()
            return

        self.snake.insert(0, new_head)

        if abs(new_head[0] - self.food[0]) < self.cell_size and abs(new_head[1] - self.food[1]) < self.cell_size:
            self.score += 1
            self.food = [randint(0, int(Window.width/self.cell_size)-1)*self.cell_size,
                        randint(0, int(Window.height/self.cell_size)-1)*self.cell_size]
        else:
            self.snake.pop()

    def reset_game(self):
        self.snake = [(100, 100), (80, 100), (60, 100)]
        self.direction = [20, 0]
        self.score = 0

    def on_touch_down(self, touch):
        x, y = touch.pos
        head_x, head_y = self.snake[0]

        if abs(x - head_x) > abs(y - head_y):
            if x > head_x and self.direction[0] == 0:
                self.direction = [20, 0]
            elif x < head_x and self.direction[0] == 0:
                self.direction = [-20, 0]
        else:
            if y > head_y and self.direction[1] == 0:
                self.direction = [0, 20]
            elif y < head_y and self.direction[1] == 0:
                self.direction = [0, -20]

class SnakeApp(App):
    def build(self):
        return SnakeGame()

if __name__ == '__main__':
    SnakeApp().run()