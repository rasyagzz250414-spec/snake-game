[app]
title = Snake Game
package.name = snakegame
package.domain = org.test
source.dir =.
source.include_exts = py,png,jpg,kv,atlas
version = 0.1
requirements = python3,kivy

[android]
android.api = 31
android.minapi = 21
android.sdk_path =
android.ndk_path =
android.ndk_version = 23b